import 'package:latlong2/latlong.dart';

final LatLng trioLocation = LatLng(-7.793663, 110.400068);
const String trioName = "Rumah Trio";
const String trioImagePath = 'assets/trio.jpg';

// # ------------------------------ #//
// #       Pembuat Proyek           #//
// #   > Ludang prasetyo .N         #//
// #   > Teknik Komputer S1         #//
// #   > 225510017                  #//
// #                                #//
// # ------------------------------ #//