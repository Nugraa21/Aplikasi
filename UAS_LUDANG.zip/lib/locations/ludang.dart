import 'package:latlong2/latlong.dart';

final LatLng ludangLocation = LatLng(-7.820680, 110.426558);
const String ludangName = "Rumah Ludang (Pembuat Aplikasi)";
const String ludangImagePath = 'assets/ludang.jpg';

//-------------------------------------------//
//
// import 'package:latlong2/latlong.dart';                         <<<  Import dart
//                                                                 
// final LatLng ludangLocation = LatLng(-7.820680, 110.426558);    <<< Memasukan kordinat lokai 
// const String ludangName = "Rumah Ludang (Pembuat Aplikasi)";    <<< Menampilkan nama 
// const String ludangImagePath = 'assets/ludang.jpg';             <<< Menambahkan Foto 
//
//-------------------------------------------//