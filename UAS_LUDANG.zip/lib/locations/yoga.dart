import 'package:latlong2/latlong.dart';

final LatLng yogaLocation = LatLng(-2.461111, 106.131780);
const String yogaName = "Rumah Yoga Saputra";
const String yogaImagePath = 'assets/yoga.jpg';

// # ------------------------------ #//
// #       Pembuat Proyek           #//
// #   > Ludang prasetyo .N         #//
// #   > Teknik Komputer S1         #//
// #   > 225510017                  #//
// #                                #//
// # ------------------------------ #//