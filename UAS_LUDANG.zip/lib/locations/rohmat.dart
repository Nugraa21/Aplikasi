import 'package:latlong2/latlong.dart';

final LatLng rohmatLocation = LatLng(-7.818056, 110.392439);
const String rohmatName = "Rumah Rohmat Cahyo .S";
const String rohmatImagePath = 'assets/rohmat.jpg';

// # ------------------------------ #//
// #       Pembuat Proyek           #//
// #   > Ludang prasetyo .N         #//
// #   > Teknik Komputer S1         #//
// #   > 225510017                  #//
// #                                #//
// # ------------------------------ #//