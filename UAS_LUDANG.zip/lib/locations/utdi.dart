import 'package:latlong2/latlong.dart';

final LatLng utdiLocation = LatLng(-7.792784062515026, 110.4083096326256);
const String utdiName = "UTDI";
const String utdiImagePath = 'assets/utdi.jpg';

// # ------------------------------ #//
// #       Pembuat Proyek           #//
// #   > Ludang prasetyo .N         #//
// #   > Teknik Komputer S1         #//
// #   > 225510017                  #//
// #                                #//
// # ------------------------------ #//