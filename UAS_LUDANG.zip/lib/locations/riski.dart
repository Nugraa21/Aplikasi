import 'package:latlong2/latlong.dart';

final LatLng riskiLocation = LatLng(-7.793475, 110.408455);
const String riskiName = "Rumah Riski";
const String riskiImagePath = 'assets/riski.jpg';

// # ------------------------------ #//
// #       Pembuat Proyek           #//
// #   > Ludang prasetyo .N         #//
// #   > Teknik Komputer S1         #//
// #   > 225510017                  #//
// #                                #//
// # ------------------------------ #//