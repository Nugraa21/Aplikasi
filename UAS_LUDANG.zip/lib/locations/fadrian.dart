import 'package:latlong2/latlong.dart';

final LatLng fadrianLocation = LatLng(-5.512911, 122.595906);
const String fadrianName = "Rumah Muhammad Fadrian .S";
const String fadrianImagePath = 'assets/fadrian.jpg';

// # ------------------------------ #//
// #       Pembuat Proyek           #//
// #   > Ludang prasetyo .N         #//
// #   > Teknik Komputer S1         #//
// #   > 225510017                  #//
// #                                #//
// # ------------------------------ #//